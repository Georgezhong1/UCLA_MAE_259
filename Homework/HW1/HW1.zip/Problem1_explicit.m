clc; clear; close all;
%% Global Variable

% Variable
% number of vertices
N = 3;

%Density
densMetal = 7000;
densFluid = 1000;
dDensity = densMetal - densFluid;

% Spheres Properties
R1 = 0.005;
R2 = 0.025;
R3 = 0.005;
m1 = 4/3*pi()*densMetal*R1^3;
m2 = 4/3*pi()*densMetal*R2^3;
m3 = 4/3*pi()*densMetal*R3^3;

% Time step
dt = 1e-5;  % second4

% Rod Properties
RodLength = 0.1; 
RodRadius = 0.001;
deltaL = RodLength / (N-1);

% Young's modulus
Y = 1e9;

% Gravity
g = 9.81;

% viscosity
visc = 1000;

% total Time
totalTime = 10;

% Number of Quantities
ne = N -1; % Number of Edges
EI = Y * pi() * RodRadius^4 / 4;
EA = Y * pi() * RodRadius^2;

% Geometry
nodes = zeros(N,2);
for c = 1:N
    nodes(c,1) = (c-1)*deltaL 
end

% Mass Matrix
M = zeros(2*N, 2*N);
M(1,1) = 4/3*pi()*R1^3*densMetal;
M(2,2) = 4/3*pi()*R1^3*densMetal;
M(3,3) = 4/3*pi()*R2^3*densMetal;
M(4,4) = 4/3*pi()*R2^3*densMetal;
M(5,5) = 4/3*pi()*R3^3*densMetal;
M(6,6) = 4/3*pi()*R3^3*densMetal;

% Viscous damping matrix
C = zeros(6,6);
C1 = 6*pi()*visc*R1;
C2 = 6*pi()*visc*R2;
C3 = 6*pi()*visc*R3;
C(1,1) = C1;
C(2,2) = C1;
C(3,3) = C2;
C(4,4) = C2;
C(5,5) = C3;
C(6,6) = C3;

% Gravity
W = zeros(2*N,1);
W(2)= -4/3*pi()*R1^3*dDensity*g;
W(4)= -4/3*pi()*R2^3*dDensity*g;
W(6)= -4/3*pi()*R3^3*dDensity*g;

% Initial DOF vector
q0 = zeros(2*N,1);
for c=1:N
    q0 (2*c - 1) = nodes(c,1);
    q0 (2*c) = nodes(c,2);
end

% Pos and Velo
q = q0;                 % DOF vector
u = (q - q0) / dt;      % Velo Vector

% Time steps
N_steps = round(totalTime / dt);
all_yq = zeros(6,N_steps);      % y - position
all_yv = zeros(6,N_steps);      % y - velocity

all_yq(:,1) = q;
all_yv(:,1) = u;

tol = EI / RodLength^2 * 1e-3;
% Time Matching
for c = 2:N_steps
    fprintf('Time = %f\n', (c-1)*dt);
    f = zeros(6,1);
    
    % compute q(tk+1)
    % Elastic E
    % spring # 1 b/t 1-2
        xk = q(1);
        yk = q(2);
        xkpl = q(3);
        ykpl = q(4);
        dF = gradEs (xk, yk, xkpl, ykpl, deltaL, EA);
        f(1:4) = f(1:4) - dF;
    
        % spring # 2 between 2-3
        xk = q(3);
        yk = q(4);
        xkpl = q(5);
        ykpl = q(6);
        dF = gradEs (xk, yk, xkpl, ykpl, deltaL, EA);
        f(3:6) = f(3:6) - dF;
    
        % bending spring b/t node 1, 2, 3
        xkml = q(1);
        ykml = q(2);
        xk = q(3);
        yk = q(4);
        xkpl = q(5);
        ykpl = q(6);
        curvature0 = 0;
        dF = gradEb (xkml, ykml, xk, yk, xkpl, ykpl, curvature0, deltaL, EI);
        f(1:6) = f(1:6)-dF;

        % Viscousity
        visc = C*u; 
        f(1:6) = f(1:6)-visc;

        % Weight
        f = f+W;

        % Intermidia step 1
%         step1 = f* (dt \(M)) + u;
        step1 = dt*inv(M) *f +u;

        % Intermidia step 2
        q = step1*dt + q;

        % update
        u = (q - q0)/dt;     % velocity
        q0 = q;             % Position

        % storing value
        all_yq(:,c) = q;
        all_yv(:,c) = u;
end
%%
figure(1);
for i = 1:10000:length(all_yq)
    plot(all_yq(1:2:end,i), all_yq(2:2:end,i), 'ro-');
    axis equal
    drawnow
end
%%
figure (2);
timeArray =  (1:N_steps)*dt;
plot(timeArray, all_yv(N+1,:), 'k-');
xlabel('Time, t [sec]');
ylabel('Velocity of mid-node, v [meter/sec]')