# UCLA MAE 259 HW 1
1. The Problem 1 is separated into 2 Files, Please Run them separately.

2. Please keep all the file under same repository

3. Run Problem1_implicit.m directly as a whole

4. Run Problem1_explicit.m directly as a whole

3. Run Problem2.m directly as a whole

3. Run Problem3.m directly as a whole